const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Node.js Express App</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 40px;
                background-color: #f0f8ff;
                color: #333;
            }
            .container {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                background-color: white;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 {
                color: #2c3e50;
                border-bottom: 2px solid #3498db;
                padding-bottom: 10px;
            }
            .footer {
                margin-top: 20px;
                text-align: center;
                color: #7f8c8d;
                font-size: 0.9em;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Welcome to My Node.js Express App!</h1>
            <p>This application is running on port 3000 and being served through Nginx.</p>
            
            <h2>Features</h2>
            <ul>
                <li>Built with Express.js</li>
                <li>Served by Nginx reverse proxy</li>
                <li>Running on port 3000</li>
            </ul>
            
            <h2>Try these routes:</h2>
            <ul>
                <li><a href="/api/hello">/api/hello</a> - JSON API endpoint</li>
                <li><a href="/about">/about</a> - About page</li>
            </ul>
            
            <div class="footer">
                <p>Powered by Node.js and Express | <span id="datetime"></span></p>
            </div>
        </div>

        <script>
            document.getElementById('datetime').textContent = new Date().toLocaleString();
        </script>
    </body>
    </html>
  `);
});

app.get('/api/hello', (req, res) => {
  res.json({ message: 'Hello from Express API!', timestamp: new Date() });
});

app.get('/about', (req, res) => {
  res.send(`
    <div class="container">
      <h1>About This Application</h1>
      <p>This is a simple Node.js application using the Express framework.</p>
      <p><a href="/">Return to home</a></p>
    </div>
  `);
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

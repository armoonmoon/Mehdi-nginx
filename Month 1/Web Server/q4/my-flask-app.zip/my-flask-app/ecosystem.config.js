module.exports = {
  apps: [{
    name: 'my-flask-app',
    script: 'gunicorn',
    args: '-w 4 -b 0.0.0.0:3001 wsgi:app',
    interpreter: 'none',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production'
    }
  }]
}

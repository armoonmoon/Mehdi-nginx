from flask import Flask, render_template_string
from datetime import datetime

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Flask App</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #fff0f5;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            border-bottom: 2px solid #e74c3c;
            padding-bottom: 10px;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            color: #7f8c8d;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to My Python Flask App!</h1>
        <p>This application is running on port 3000 and being served through Nginx.</p>
        
        <h2>Features</h2>
        <ul>
            <li>Built with Flask</li>
            <li>Served by Nginx reverse proxy</li>
            <li>Running on port 3000</li>
        </ul>
        
        <h2>Try these routes:</h2>
        <ul>
            <li><a href="/api/hello">/api/hello</a> - JSON API endpoint</li>
            <li><a href="/about">/about</a> - About page</li>
        </ul>
        
        <div class="footer">
            <p>Powered by Python and Flask | {{ current_time }}</p>
        </div>
    </div>
</body>
</html>
"""

@app.route('/')
def home():
    return render_template_string(HTML_TEMPLATE, current_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

@app.route('/api/hello')
def hello_api():
    return {
        "message": "Hello from Flask API!",
        "timestamp": datetime.now().isoformat()
    }

@app.route('/about')
def about():
    return """
    <div class="container">
      <h1>About This Application</h1>
      <p>This is a simple Python application using the Flask framework.</p>
      <p><a href="/">Return to home</a></p>
    </div>
    """

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)
